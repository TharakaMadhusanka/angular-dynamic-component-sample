# upgraded-octo-happiness
Sample Implementation - Angular Dynamic Component Creation with Inputs &amp; Output emitters. 
